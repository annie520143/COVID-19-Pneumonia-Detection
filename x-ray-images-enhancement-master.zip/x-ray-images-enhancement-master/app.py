from src.algorithms.runner import AlgorithmRunner
import os

def main():
	data_path = 'VALID/'
	save_path = 'VALID1/'
	datalist = os.listdir(data_path)

	#for i,file_name in enumerate(datalist):
		#print(i)
	ar = AlgorithmRunner(data_path,save_path)
	ar.run()

if __name__ == "__main__":
	main()